/*
 * freq.h
 *
 *  Created on: May 14, 2025
 *      Author: tharun
 */

#ifndef APP_FREQ_FREQ_H_
#define APP_FREQ_FREQ_H_

#include "stm32f4xx_hal.h"
#include "main.h"
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim);


#endif /* APP_FREQ_FREQ_H_ */
